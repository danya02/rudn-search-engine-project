import documents
import search_views
import snippet_tools
import term_idf_views
BLUEPRINT_LIST = [documents.bp, search_views.bp, snippet_tools.bp, term_idf_views.bp]
